<?php
session_start();
?>

<?php
include("connection.php");

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $pwd = $_POST['password'];

    $query = "SELECT * FROM admissionform WHERE username ='$username' AND password ='$pwd'";
    $data = mysqli_query($connection, $query);

    $total = mysqli_num_rows($data);

    if ($total == 1) {
        $result = mysqli_fetch_assoc($data);
        if ($result["usertype"] == "user") {
            header('Location: userdashboard.php?id=' . $result["id"]); // Correct concatenation
            exit(); // Always exit after a header redirect
        } elseif ($result["usertype"] == "admin") {
            session_start();
            $_SESSION['user_name'] = $username;
            // Redirect to dashboard.php with the username as a query parameter
            header('Location: dashboard.php?username=' . urlencode($username));
            exit();
        }
    } else {
        echo "<script>alert('Username or Password is wrong');</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <title>Login</title>
</head>

<body>
    <section>
        <div class="container">
            <div class="justify-content-center d-flex align-items-center vh-100">
                
            
            <form action="" method="POST" autocomplete="off" class="border border-5 border-danger p-5">
                    <h4 class="text-center">Login</h4>
                    <input type="text" class="mt-3 rounded px-3" placeholder="Username" name="username" required>
                    <br>
                    <input type="password" class="mt-3 rounded px-3" placeholder="Password" name="password" required>
                    <br>
                    <button class="mt-3 btn btn-primary d-block mx-auto" type="submit" name="login">Login</button>

                <a href="index.php">Create Account.</a>
                </form>
            </div>
        </div>
        </div>
    </section>
</body>

</html>