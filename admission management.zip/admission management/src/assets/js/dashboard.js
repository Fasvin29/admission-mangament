$(function () {
  function dashboard() {
      // Fetch data and render the chart
      fetch('fetch_data.php')
          .then(response => response.json())
          .then(data => {
              const labels = data.map(row => row.yearofpassing);
              const dataset = data.map(row => row.total);

              const chartOptions = {
                  series: [{
                      name: "Number of Students",
                      data: dataset,
                  }],
                  chart: {
                      type: "bar",
                      height: 345,
                      offsetX: -15,
                      toolbar: { show: true },
                      foreColor: "#adb0bb",
                      fontFamily: 'inherit',
                  },
                  colors: ["#5D87FF", "#49BEFF"],
                  plotOptions: {
                      bar: {
                          horizontal: false,
                          columnWidth: "35%",
                          borderRadius: [6],
                          borderRadiusApplication: 'end',
                          borderRadiusWhenStacked: 'all',
                      },
                  },
                  dataLabels: {
                      enabled: false,
                  },
                  grid: {
                      borderColor: "rgba(0,0,0,0.1)",
                      strokeDashArray: 3,
                      xaxis: {
                          lines: {
                              show: false,
                          },
                      },
                  },
                  xaxis: {
                      type: "category",
                      categories: labels,
                      labels: {
                          style: { cssClass: "grey--text lighten-2--text fill-color" },
                      },
                  },
                  yaxis: {
                      show: true,
                      labels: {
                          style: {
                              cssClass: "grey--text lighten-2--text fill-color",
                          },
                      },
                  },
                  stroke: {
                      show: true,
                      width: 3,
                      lineCap: "butt",
                      colors: ["transparent"],
                  },
                  tooltip: {
                      theme: "light",
                  },
                  responsive: [
                      {
                          breakpoint: 600,
                          options: {
                              plotOptions: {
                                  bar: {
                                      borderRadius: 3,
                                  },
                              },
                          },
                      },
                  ],
              };

              // Render the chart
              const chart = new ApexCharts(document.querySelector("#chart"), chartOptions);
              chart.render();
          })
          .catch(error => console.error("Error fetching data:", error));
  }

  // Initialize the dashboard
  dashboard();
});
