<?php
$serverName ="localhost";
$username ="root";
$password ="";
$dbname = "collegeadmission";

$connection = mysqli_connect($serverName,$username,$password,$dbname);

// if($connection)
// {
//     echo "done";
// }
// else
// {
//     echo "no connection";
// }
?>