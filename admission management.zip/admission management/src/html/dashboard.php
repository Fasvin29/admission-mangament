<?php
session_start();


include("connection.php");

$user = $_SESSION['user_name'];
$usertype = $_SESSION['usertype_id'];
$id =  $_SESSION['id'];

if($usertype == 2){
  $id = $_GET['id'];
}

// echo $id;

$query = "SELECT * FROM user WHERE id = '$id'";
$data = mysqli_query($connection, $query);

$result = mysqli_fetch_assoc($data);


if ($user == true) {
} else {
  header('location:login.php'); //relocates to display.php page
}


function getCount($tableName)
{
  $usertype = $_SESSION['usertype_id'];
  $id =  $_SESSION['id'];
  global $connection; // Use the global connection variable

  // echo $usertype;
  if ($usertype == 1) {
    $query = "SELECT COUNT(*) AS total FROM $tableName";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
  } elseif ($usertype == 3) {
    $query = "SELECT COUNT(*) AS total FROM $tableName WHERE createdby = $id";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
  }
}

function getCount2($tableName, $userid)
{
  $usertype = $_SESSION['usertype_id'];
  $id =  $_SESSION['id'];
  global $connection;
  if ($usertype == 1) {
    global $connection; // Use the global connection variable
    $query = "SELECT COUNT(*) AS total FROM $tableName WHERE usertype_id = $userid";
    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['total'];
  } elseif ($usertype == 3) {
  }
}
?>

<?php include("header.php"); ?>


<!--  Header End -->
<?php if ($usertype != 2) { ?>
  <div class="container-fluid">
    <!--  Row 1 -->
    <div class="row">
      <div class="col-lg-8 d-flex align-items-strech">
        <div class="card w-100 shadow-lg border border-5">
          <div class="card-body">
            <div class="d-sm-flex d-block align-items-center justify-content-between mb-9">
              <div class="mb-3 mb-sm-0">
                <h5 class="card-title fw-semibold">No. of students per year</h5>
              </div>
            </div>
            <div id="chart"></div>
          </div>
        </div>
      </div>
      <div class="col-lg-4">
        <!-- Yearly Breakup -->
        <?php
        if ($usertype == 1) {
        ?>
          <div class="card overflow-hidden shadow-lg border border-3">
            <div class="card-body p-4">
              <h5 class="card-title mb-9 fw-semibold text-center">Total number of students</h5>
              <div>
                <h4 class="fw-semibold mb-3 text-center"><?php echo getCount('admissionform'); ?></h4>
              </div>
            </div>
          </div>
          <div class="card overflow-hidden shadow-lg border border-3">
            <div class="card-body p-4">
              <h6 class="card-title mb-9 fw-semibold text-center">Total number of Admins</h6>
              <div class="text-center">
                <h5 class="fw-semibold mb-3 text-center"><?php echo getCount2('user', '1'); ?></h5>
                <a href="userdisplay.php?usertype_id=1" class="btn btn-primary">View Admins</a>
              </div>
              <hr>
              <h6 class="card-title mb-9 fw-semibold text-center mt-3">Total number of Agents</h6>
              <div class="text-center">
                <h5 class="fw-semibold mb-3 text-center"><?php echo getCount2('user', '3'); ?></h5>
                <a href="userdisplay.php?usertype_id=3" class="btn btn-primary">View Agents</a>
              </div>
              <hr>
              <h5 class="card-title mb-9 fw-semibold text-center mt-3">Total number of Users</h5>
              <div class="text-center">
                <h4 class="fw-semibold mb-3 text-center"><?php echo getCount2('user', '2'); ?></h4>
                <a href="userdisplay.php?usertype_id=2" class="btn btn-primary">View Users</a>
              </div>
            </div>
          </div>
        <?php
        } elseif ($usertype == 3) {
        ?>
          <div class="card overflow-hidden shadow-lg border border-3">
            <div class="card-body p-4">
              <h5 class="card-title mb-9 fw-semibold text-center">Total number of students</h5>
              <div>
                <h4 class="fw-semibold mb-3 text-center"><?php echo getCount('admissionform'); ?></h4>
              </div>
            </div>
          </div>
        <?php
        }
        ?>
      </div>
    </div>
  </div>
<?php } else { ?>
  <center>
    <div class="container">
      <br><br><br><br>
      <h6>Fullname = <?php echo $result['fullname']; ?></h6>
      <br>
      <h6>Email = <?php echo $result['email']; ?></h6>
      <br>
      <h6>Phone number = <?php echo $result['phone']; ?></h6>
      <br>
      <h6>Usertype = <?php
                      $usertype = $_SESSION['usertype_id'];

                      if ($usertype == 1) {
                        echo "Admin";
                      } elseif ($usertype == 3) {
                        echo "Agent";
                      } else {
                        echo "Student";
                      } ?></h6>
    </div>
  </center>
<?php } ?>
</div>
</div>
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebarmenu.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/apexcharts/dist/apexcharts.min.js"></script>
<script src="../assets/libs/simplebar/dist/simplebar.js"></script>
<script src="../assets/js/dashboard.js"></script>
</body>

</html>