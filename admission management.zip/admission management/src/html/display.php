<?php
session_start();
?>


<?php
include("connection.php");

$user = $_SESSION['user_name'];
$usertype = $_SESSION['usertype_id'];
$id =  $_SESSION['id'];

if ($user == true) {
} else {
  header('location:login.php'); //relocates to display.php page
}

if ($usertype == 1) {
  $query = "SELECT * FROM admissionform"; // Fetch all values and display
}elseif ($usertype == 3) {
  $query = "SELECT * FROM admissionform WHERE createdby = $id"; // Fetch all values and display
}

$data = mysqli_query($connection, $query); // Execute query
$total = mysqli_num_rows($data); // Number of rows in the table
?>

<?php include("header.php") ?>

<!--  Header End -->
<div class="container-fluid">
  <div class="card shadow-lg border border-5">
    <h5 class="card-title fw-semibold m-4">Applicant Details</h5>
    <div class="card-body">
      <div class="d-flex justify-content-end">
        <a class="btn btn-primary text-end" href="index_new.php" aria-expanded="false">
          <span>
            <i class="ti ti-file-description"></i>
          </span>
          <span class="hide-menu">Add new</span>
        </a>
      </div>
      <div class="table-responsive ">
        <table class="table table-bordered table-striped" id="admissionTable">
          <thead>
            <tr>
              <th>ID</th>
              <!-- <th>Photo</th> -->
              <th>First Name</th>
              <th>Last Name</th>
              <th>Date of Birth</th>
              <th>Phone Number</th>
              <th>City</th>
              <th>Pincode</th>
              <th>Qualification</th>
              <th>Marks</th>
              <th>Operations</th>
            </tr>
          </thead>

          <tbody>
            <?php
            while ($result = mysqli_fetch_assoc($data)) {
              echo "<tr>
                            <td>" . $result['id'] . "</td>
                            <!-- <td><img src='" . $result['photo'] .  "' height='100px'></td> -->
                            <td>" . $result['firstName'] . "</td>
                            <td>" . $result['lastName'] . "</td>
                            <td>" . $result['dateOfBirth'] . "</td>
                            <td>" . $result['phoneNumber'] . "</td>
                            <td>" . $result['city'] . "</td>
                            <td>" . $result['pincode'] . "</td>
                            <td>" . $result['qualification'] . "</td>
                            <td>" . $result['marks'] . "</td>
                            <td><div class='d-flex gap-2'>
                                    <a class='btn btn-info ' data-bs-toggle='modal' data-bs-target='#viewModal' data-id='" . $result['id'] . "'>View</a> 
                                    <a class='btn btn-primary' href='edit_design.php?id=" . $result['id'] . "'>Edit</a> 
                                    <a class='btn btn-danger' href='delete.php?id=" . $result['id'] . "' onclick='return checkdelete()'>Delete</a>
                                    </div>
                                    <a class='btn btn-success my-2' data-bs-toggle='modal' data-bs-target='#myModal' data-id='" . $result['id'] . "'>Communication Address</a> 
                                </td>
                        </tr>";
            }
            ?>
          </tbody>
        </table>
      </div>

      <!-- communication address modal -->
      <div class='modal' id='myModal'>
        <div class='modal-dialog modal-lg'>
          <div class='modal-content'>

            <div class='modal-header'>
              <h4 class='modal-title'>Communication Address</h4>
              <button type='button' class='btn-close' data-bs-dismiss='modal'></button>
            </div>

            <div class='modal-body'>
              <div class="table-responsive">
                <table class='table table-bordered table-striped'>
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Street Address</th>
                      <th>City</th>
                      <th>Country</th>
                      <th>Pincode</th>
                      <th>State</th>
                      <th>Admission ID</th>
                      <th>Operations</th>
                    </tr>
                  </thead>
                  <tbody id="communication-address-table-body">
                    <!-- Data will be dynamically inserted here -->
                  </tbody>
                </table>
              </div>
            </div>

            <div class='modal-footer'>
              <button type='button' class='btn btn-danger' data-bs-dismiss='modal'>Close</button>
            </div>

          </div>
        </div>
      </div>


      <!-- view modal -->
      <div class="modal" id="viewModal">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title">Applicant's details</h4>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="card">
                    <img class="card-img-top" src="" alt="Card image" style="width:100%">
                    <div class="card-body">
                      <h4 class="card-title" id="cardname"></h4>
                    </div>
                  </div>
                </div>
                <div class="col-md-6">
                  <p><strong>Date of birth:</strong> <span id="carddob"></span></p>
                  <p><strong>Age:</strong> <span id="cardage"></span></p>
                  <p><strong>Phone number:</strong> <span id="cardph"></span></p>
                  <p><strong>Street address:</strong> <span id="cardstreet"></span></p>
                  <p><strong>City:</strong> <span id="cardcity"></span></p>
                  <p><strong>Country:</strong> <span id="cardcountry"></span></p>
                  <p><strong>State:</strong> <span id="cardstate"></span></p>
                  <p><strong>Pincode:</strong> <span id="cardpin"></span></p>
                </div>
              </div>
              <hr>
              <h4>Education details</h4>
              <p><strong>College name:</strong> <span id="modelcollege"></span></p>
              <p><strong>Highest qualification:</strong> <span id="modelqualification"></span></p>
              <p><strong>Marks:</strong> <span id="modelmarks"></span></p>
              <p><strong>Year of passing:</strong> <span id="modelyop"></span></p>
              <br>
              <h4>Parent details</h4>
              <p><strong>Parent name:</strong> <span id="modalparentname"></span></p>
              <p><strong>Parent phone number:</strong> <span id="modalparentph"></span></p>
              <p><strong>Occupation:</strong> <span id="modaloccupation"></span></p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</div>
</div>
</div>
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/js/sidebarmenu.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/simplebar/dist/simplebar.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
  crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.datatables.net/2.2.0/js/dataTables.js"></script>
<script>
  // Confirm deletion
  function checkdelete() {
    return confirm('Are you sure you want to delete the entire row?');
  }

  //------------------------------------------------------------------------------------------------------
  // Fetch communication address data dynamically
  $('#myModal').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget); // Button that triggered the modal
    var admissionId = button.data('id'); // Extract info from data-id attribute

    // AJAX request to fetch data
    $.ajax({
      url: 'fetch_communication_address.php',
      type: 'GET',
      data: {
        id: admissionId
      },
      success: function(response) {
        var data = JSON.parse(response);
        $('#communication-address-table-body').empty(); // Clear previous data

        // Populate table with fetched data
        data.forEach(function(item) {
          $('#communication-address-table-body').append(
            '<tr>' +
            '<td>' + item.id + '</td>' +
            '<td>' + item.streetaddress + '</td>' +
            '<td>' + item.city + '</td>' +
            '<td>' + item.country + '</td>' +
            '<td>' + item.pincode + '</td>' +
            '<td>' + item.state + '</td>' +
            '<td>' + item.admissionid + '</td>' +
            '<td><a class="btn btn-primary" href="edit_communication.php?id=' + item.id + '">Edit</a> <a class="btn btn-danger" href="delete_communication.php?id=" ' + item.id + ' " onclick= return checkdelete()">Delete</a> </td>' +
            '</tr>'
          );
        });
      },
      error: function(xhr, status, error) {
        console.error('Error fetching data:', error);
      }
    });
  });

  // ------------------------------------------------------------------------------------------------------------------------
  $('#viewModal').on('show.bs.modal', function(event) {
    var button = $(event.relatedTarget); // Button that triggered the modal
    var admissionId = button.data('id'); // Extract the ID from data-id attribute

    // AJAX request to fetch details
    $.ajax({
      url: 'fetch_form_details.php',
      type: 'GET',
      data: {
        id: admissionId
      },
      success: function(response) {
        var data = JSON.parse(response);

        if (data.error) {
          $('.modal-body').html('<p class="text-danger">' + data.error + '</p>');
        } else {
          // Populate modal with fetched data
          $('#cardname').text(data.firstName + ' ' + data.middleName + ' ' + data.lastName);
          $('#carddob').text(data.dateOfBirth);
          $('#cardage').text(calculateAge(data.dateOfBirth));
          $('#cardph').text(data.phoneNumber); // Ensure phone number is displayed correctly
          $('#cardstreet').text(data.StreetAddress);
          $('#cardcity').text(data.city);

          // Ensure state and country are correctly displayed as strings
          $('#cardcountry').text(data.country ? data.country : 'Not available');
          $('#cardstate').text(data.state ? data.state : 'Not available');

          $('#cardpin').text(data.pincode);
          $('#modelcollege').text(data.school);
          $('#modelqualification').text(data.qualification);
          $('#modelmarks').text(data.marks);
          $('#modelyop').text(data.yearofpassing);
          $('#modalparentname').text(data.parentfirstname + ' ' + data.parentmiddlename + ' ' + data.parentlastname);
          $('#modalparentph').text(data.parentphonenumber);
          $('#modaloccupation').text(data.occupation);

          // Set the image source dynamically
          $('.card-img-top').attr('src', data.photo);
        }
      },
      error: function(xhr, status, error) {
        console.error('Error fetching details:', error);
        $('.modal-body').html('<p class="text-danger">Failed to load details.</p>');
      }
    });
  });

  // Helper function to calculate age
  function calculateAge(dob) {
    var birthDate = new Date(dob);
    var diff = Date.now() - birthDate.getTime();
    var ageDate = new Date(diff);
    return Math.abs(ageDate.getUTCFullYear() - 1970);
  }

  // -------------------------------------------------------------------------------------------------------------------------
  // Initialize DataTable
  $(document).ready(function() {
    $('#admissionTable').DataTable();
  });
</script>
</body>

</html>