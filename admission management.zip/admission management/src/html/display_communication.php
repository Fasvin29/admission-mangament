<?php
session_start();
?>


<?php
include("connection.php");

$user = $_SESSION['user_name'];

if($user == true)
{
    
}
else{
    header('location:login.php'); //relocates to display.php page
}

$query = "SELECT * FROM communicationaddress"; //fetch all the values and display
$data = mysqli_query($connection, $query); //it is used to execute queries on a MySQL database. It allows you to send SQL queries to the database.
$total = mysqli_num_rows($data); //no. of rows(entries) in the table

// you can use if condition if you want to display the table, only if the table contains entry (if no entries, blank page will be displayed)
// if ($total !=0)
// {
?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Communication Address</title>
  <link rel="shortcut icon" type="image/png" href="../assets/images/logos/favicon.png" />
  <link rel="stylesheet" href="../assets/css/styles.min.css" />
</head>

<body>
  <!--  Body Wrapper -->
  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
    <!-- Sidebar Start -->
    <aside class="left-sidebar">
      <!-- Sidebar scroll-->
      <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
          <a href="#" class="text-nowrap logo-img">
            <img src="logo.png" width="180" alt="" />
          </a>
          <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
            <i class="ti ti-x fs-8"></i>
          </div>
        </div>
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
          <ul id="sidebarnav">
            <li class="nav-small-cap">
              <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
              <span class="hide-menu">Home</span>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="./index.html" aria-expanded="false">
                <span>
                  <i class="ti ti-layout-dashboard"></i>
                </span>
                <span class="hide-menu">Dashboard</span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="addnew.php" aria-expanded="false">
                <span>
                  <i class="ti ti-file-description"></i>
                </span>
                <span class="hide-menu">Add new</span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="studentstable.php" aria-expanded="false">
                <span>
                  <i class="ti ti-article"></i>
                </span>
                <span class="hide-menu">View students</span>
              </a>
            </li>
          </ul>
        </nav>
        <!-- End Sidebar navigation -->
      </div>
      <!-- End Sidebar scroll-->
    </aside>
    <!--  Sidebar End -->
    <!--  Main wrapper -->
    <div class="body-wrapper">
      <!--  Header Start -->
      <header class="app-header">
        <nav class="navbar navbar-expand-lg navbar-light">
          <ul class="navbar-nav">
            <li class="nav-item d-block d-xl-none">
              <a class="nav-link sidebartoggler nav-icon-hover" id="headerCollapse" href="javascript:void(0)">
                <i class="ti ti-menu-2"></i>
              </a>
            </li>
          </ul>
          <div class="navbar-collapse justify-content-end px-0" id="navbarNav">
            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">
              <li class="nav-item dropdown">
                <a class="nav-link nav-icon-hover" href="javascript:void(0)" id="drop2" data-bs-toggle="dropdown"
                  aria-expanded="false">
                  <img src="dp.jpg" alt="" width="35" height="35" class="rounded-circle">
                </a>
                <div class="dropdown-menu dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop2">
                  <div class="message-body">
                    <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                      <i class="ti ti-user fs-6"></i>
                      <p class="mb-0 fs-3">My Profile</p>
                    </a>
                    <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                      <i class="ti ti-mail fs-6"></i>
                      <p class="mb-0 fs-3">My Account</p>
                    </a>
                    <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                      <i class="ti ti-list-check fs-6"></i>
                      <p class="mb-0 fs-3">My Task</p>
                    </a>
                    <a href="./authentication-login.html" class="btn btn-outline-primary mx-3 mt-2 d-block">Logout</a>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!--  Header End -->
      <div class="container-fluid">
        <div class="container-fluid">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">Communication Address</h5>
              <div class="card">
                <div class="card-body">

                  <div class="table-responsive mt-5 pt-3">
                    <table class="table table-bordered table-striped" > <!-- table creation -->
                        <tr>
                            <th>ID</th>
                            <th>Street Address</th>
                            <th>City</th>
                            <th>Country</th>
                            <th>Pincode</th>
                            <th>State</th>
                            <th>Admission ID</th>
                            <th>Operations</th>
                        </tr>
                
                        <?php
                        while ($result = mysqli_fetch_assoc($data)) //fetch the data given by the user and store in table
                        {
                            echo "<tr>
                                    <td>" . $result['id'] . "</td>
                                    <td>" . $result['streetaddress'] . "</td>
                                    <td>" . $result['city'] . "</td>
                                    <td>" . $result['country'] . "</td>
                                    <td>" . $result['pincode'] . "</td>
                                    <td>" . $result['state'] . "</td>
                                    <td>" . $result['admissionid'] . "</td>
                                    <td><div class='d-flex justify-content-center gap-2'>
                                            <a class='btn btn-primary' href='edit_communication.php?id=$result[id]'>Edit</a> 
                                        </div>
                                    </td>
                                </tr>";
                        }
                
                        // } closing of if condition
                        ?>
                    </table>
                    </div>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/sidebarmenu.js"></script>
  <script src="../assets/js/app.min.js"></script>
  <script src="../assets/libs/simplebar/dist/simplebar.js"></script>

  <script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4="
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.datatables.net/2.2.0/js/dataTables.js"></script>
  <script>
    // Confirm deletion
    function checkdelete() {
      return confirm('Are you sure you want to delete the entire row?');
    }

    //------------------------------------------------------------------------------------------------------
    // Fetch communication address data dynamically
    $('#myModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget); // Button that triggered the modal
      var admissionId = button.data('id'); // Extract info from data-id attribute

      // AJAX request to fetch data
      $.ajax({
        url: 'fetch_communication_address.php',
        type: 'GET',
        data: {
          id: admissionId
        },
        success: function (response) {
          var data = JSON.parse(response);
          $('#communication-address-table-body').empty(); // Clear previous data

          // Populate table with fetched data
          data.forEach(function (item) {
            $('#communication-address-table-body').append(
              '<tr>' +
              '<td>' + item.id + '</td>' +
              '<td>' + item.streetaddress + '</td>' +
              '<td>' + item.city + '</td>' +
              '<td>' + item.country + '</td>' +
              '<td>' + item.pincode + '</td>' +
              '<td>' + item.state + '</td>' +
              '<td>' + item.admissionid + '</td>' +
              '<td><a class="btn btn-primary" href="edit_communication.php?id=' + item.id + '">Edit</a> <a class="btn btn-danger" href="delete_communication.php?id=" ' + item.id + ' " onclick= return checkdelete()">Delete</a> </td>' +
              '</tr>'
            );
          });
        },
        error: function (xhr, status, error) {
          console.error('Error fetching data:', error);
        }
      });
    });

    // ------------------------------------------------------------------------------------------------------------------------
    $('#viewModal').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget); // Button that triggered the modal
      var admissionId = button.data('id'); // Extract the ID from data-id attribute

      // AJAX request to fetch details
      $.ajax({
        url: 'fetch_form_details.php',
        type: 'GET',
        data: {
          id: admissionId
        },
        success: function (response) {
          var data = JSON.parse(response);

          if (data.error) {
            $('.modal-body').html('<p class="text-danger">' + data.error + '</p>');
          } else {
            // Populate modal with fetched data
            $('#cardname').text(data.firstName + ' ' + data.middleName + ' ' + data.lastName);
            $('#carddob').text(data.dateOfBirth);
            $('#cardage').text(calculateAge(data.dateOfBirth));
            $('#cardph').text(data.phoneNumber); // Ensure phone number is displayed correctly
            $('#cardstreet').text(data.StreetAddress);
            $('#cardcity').text(data.city);

            // Ensure state and country are correctly displayed as strings
            $('#cardcountry').text(data.country ? data.country : 'Not available');
            $('#cardstate').text(data.state ? data.state : 'Not available');

            $('#cardpin').text(data.pincode);
            $('#modelcollege').text(data.school);
            $('#modelqualification').text(data.qualification);
            $('#modelmarks').text(data.marks);
            $('#modelyop').text(data.yearofpassing);
            $('#modalparentname').text(data.parentfirstname + ' ' + data.parentmiddlename + ' ' + data.parentlastname);
            $('#modalparentph').text(data.parentphonenumber);
            $('#modaloccupation').text(data.occupation);

            // Set the image source dynamically
            $('.card-img-top').attr('src', data.photo);
          }
        },
        error: function (xhr, status, error) {
          console.error('Error fetching details:', error);
          $('.modal-body').html('<p class="text-danger">Failed to load details.</p>');
        }
      });
    });

    // Helper function to calculate age
    function calculateAge(dob) {
      var birthDate = new Date(dob);
      var diff = Date.now() - birthDate.getTime();
      var ageDate = new Date(diff);
      return Math.abs(ageDate.getUTCFullYear() - 1970);
    }

    // -------------------------------------------------------------------------------------------------------------------------
    // Initialize DataTable
    $(document).ready(function () {
      $('#admissionTable').DataTable();
    });
  </script>
</body>

</html>