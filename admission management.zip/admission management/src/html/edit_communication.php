<?php
session_start();
?>


<?php include("connection.php");

$user = $_SESSION['user_name'];

if($user == true)
{
    
}
else{
    header('location:login.php'); //relocates to display.php page
}

$id = $_GET['id']; // recieves the data which is passed when edit button as clicked

$query = "SELECT * FROM communicationaddress WHERE id= '$id'";

$data = mysqli_query($connection, $query);


$result = mysqli_fetch_assoc($data);


?>

<?php
if (isset($_POST['update'])) {
    $cStreet        = $_POST['cStreetAddress'];
    $cCity          = $_POST['cCity'];
    $cState         = isset($_POST['cState']) ? $_POST['cState'] : '';  // Check if state exists
    $cpincode       = $_POST['cpincode'];
    $cCountry       = isset($_POST['cCountry']) ? $_POST['cCountry'] : '';  // Check if country exists

    // Insert data into admissionform
    $query = "UPDATE  communicationaddress SET streetaddress='$cStreet',city='$cCity',country='$cCountry',pincode='$cpincode',state='$cState' WHERE id='$id'";
    $data = mysqli_query($connection, $query);

    if ($data) {
        echo "<script>alert('Your application has been updated successfully!')</script>";
?>
        <meta http-equiv="refresh" content="0;url=http://localhost/admissionform/display.php">
<?php
    } else {
        echo "<script>alert('There was an error updating your application. Please try again later.')</script>";
    }
}

?>


<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Edit Communication address</title>
  <link rel="shortcut icon" type="image/png" href="../assets/images/logos/favicon.png" />
  <link rel="stylesheet" href="../assets/css/styles.min.css" />
</head>

<body>
  <!--  Body Wrapper -->
  <div class="page-wrapper" id="main-wrapper" data-layout="vertical" data-navbarbg="skin6" data-sidebartype="full"
    data-sidebar-position="fixed" data-header-position="fixed">
    <!-- Sidebar Start -->
    <aside class="left-sidebar">
      <!-- Sidebar scroll-->
      <div>
        <div class="brand-logo d-flex align-items-center justify-content-between">
          <a href="#" class="text-nowrap logo-img">
            <img src="logo.png" width="180" alt="" />
          </a>
          <div class="close-btn d-xl-none d-block sidebartoggler cursor-pointer" id="sidebarCollapse">
            <i class="ti ti-x fs-8"></i>
          </div>
        </div>
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav scroll-sidebar" data-simplebar="">
          <ul id="sidebarnav">
            <li class="nav-small-cap">
              <i class="ti ti-dots nav-small-cap-icon fs-4"></i>
              <span class="hide-menu">Home</span>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="./index.html" aria-expanded="false">
                <span>
                  <i class="ti ti-layout-dashboard"></i>
                </span>
                <span class="hide-menu">Dashboard</span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="addnew.php" aria-expanded="false">
                <span>
                  <i class="ti ti-file-description"></i>
                </span>
                <span class="hide-menu">Add new</span>
              </a>
            </li>
            <li class="sidebar-item">
              <a class="sidebar-link" href="studentstable.php" aria-expanded="false">
                <span>
                  <i class="ti ti-article"></i>
                </span>
                <span class="hide-menu">View students</span>
              </a>
            </li>
          </ul>
        </nav>
        <!-- End Sidebar navigation -->
      </div>
      <!-- End Sidebar scroll-->
    </aside>
    <!--  Sidebar End -->
    <!--  Main wrapper -->
    <div class="body-wrapper">
      <!--  Header Start -->
      <header class="app-header">
        <nav class="navbar navbar-expand-lg navbar-light">
          <ul class="navbar-nav">
            <li class="nav-item d-block d-xl-none">
              <a class="nav-link sidebartoggler nav-icon-hover" id="headerCollapse" href="javascript:void(0)">
                <i class="ti ti-menu-2"></i>
              </a>
            </li>
          </ul>
          <div class="navbar-collapse justify-content-end px-0" id="navbarNav">
            <ul class="navbar-nav flex-row ms-auto align-items-center justify-content-end">
              <li class="nav-item dropdown">
                <a class="nav-link nav-icon-hover" href="javascript:void(0)" id="drop2" data-bs-toggle="dropdown"
                  aria-expanded="false">
                  <img src="dp.jpg" alt="" width="35" height="35" class="rounded-circle">
                </a>
                <div class="dropdown-menu dropdown-menu-end dropdown-menu-animate-up" aria-labelledby="drop2">
                  <div class="message-body">
                    <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                      <i class="ti ti-user fs-6"></i>
                      <p class="mb-0 fs-3">My Profile</p>
                    </a>
                    <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                      <i class="ti ti-mail fs-6"></i>
                      <p class="mb-0 fs-3">My Account</p>
                    </a>
                    <a href="javascript:void(0)" class="d-flex align-items-center gap-2 dropdown-item">
                      <i class="ti ti-list-check fs-6"></i>
                      <p class="mb-0 fs-3">My Task</p>
                    </a>
                    <a href="./authentication-login.html" class="btn btn-outline-primary mx-3 mt-2 d-block">Logout</a>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </nav>
      </header>
      <!--  Header End -->
      <div class="container-fluid">
        <div class="container-fluid">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title fw-semibold mb-4">Communication Address</h5>
              <div class="card">
                <div class="card-body">

                  <form action="#" method="POST">
                    <section>
                        <div>
                            <label for="address" class="form-label h5 mt-3">Communication Address</label>
                            <div id="communicationAddress" class="row">
                                <div class="col-12">
                                    <input type="text" class="form-control" placeholder="Street Address"
                                        name="cStreetAddress" value="<?php echo $result['streetaddress']; ?>" required>
                                </div>
                                <div class="col-12 col-md-6 mt-3">
                                    <input type="text" class="form-control" placeholder="City" name="cCity" value="<?php echo $result['city']; ?>" required>
                                </div>
                                <div class="col-12 col-md-6 mt-3">
                                    <select id="cCountry" class="form-select" name="cCountry" required>
                                        <option value="" selected disabled>Country</option>
                                        <option value="us"
                                            <?php if ($result['country'] == 'us') {
                                                echo "selected";
                                            }   ?>>United States</option>
                                        <option value="ca" <?php if ($result['country'] == 'ca') {
                                                                echo "selected";
                                                            }   ?>>Canada</option>
                                        <option value="uk" <?php if ($result['country'] == 'uk') {
                                                                echo "selected";
                                                            }   ?>>United Kingdom</option>
                                        <option value="au" <?php if ($result['country'] == 'au') {
                                                                echo "selected";
                                                            }   ?>>Australia</option>
                                        <option value="in" <?php if ($result['country'] == 'in') {
                                                                echo "selected";
                                                            }   ?>>India</option>
                                        <option value="jp" <?php if ($result['country'] == 'jp') {
                                                                echo "selected";
                                                            }   ?>>Japan</option>
                                    </select>
                                </div>
                                <div class="col-12 col-md-6 mt-3">
                                    <input type="number" class="form-control" placeholder="Postal/ Zip Code"
                                        name="cpincode" value="<?php echo $result['pincode']; ?>" required oninput="pincodeValidation(this)">
                                </div>
                                <div class="col-12 col-md-6 mt-3">
                                    <!-- <input type="text" class="form-control" placeholder="State" name="state" required> -->
                                    <select id="cState" class="form-select" name="cState" required>
                                        <option value="" selected disabled>Choose a state</option>
                                    </select>
                                </div>
                                
                                <br>
                                <br>
                                <br>
                                <hr>
                            </div>
                        </div>
                    </section>
                    <div class="d-flex justify-content-center">
                        <button type="button" class="btn btn-danger mx-3" onclick="window.history.back();">Cancel</button>
                        <button type="submit" class="btn btn-primary mx-3" name="update">Update</button>
                    </div>
                </form>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="../assets/libs/jquery/dist/jquery.min.js"></script>
  <script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/js/sidebarmenu.js"></script>
  <script src="../assets/js/app.min.js"></script>
  <script src="../assets/libs/simplebar/dist/simplebar.js"></script>

  <script>
    function calculateAge() {
        const dob = document.getElementById('dateOfBirth').value;
        const birthDate = new Date(dob);
        const currentDate = new Date();

        let ageYears = currentDate.getFullYear() - birthDate.getFullYear();
        let ageMonths = currentDate.getMonth() - birthDate.getMonth();
        let ageDays = currentDate.getDate() - birthDate.getDate();

        //adjusts the negative values (month 2-11 = -9, by adding 12 months it gives 3 and decreases one year)
        if (ageMonths < 0) {
            ageYears--;
            ageMonths += 12;
        }
        if (ageDays < 0) {
            ageMonths--;
            const daysInPrevMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
            ageDays += daysInPrevMonth;
        }

        document.getElementById('ageYear').value = ageYears + " year" + (ageYears === 1 ? "" : "s");
        document.getElementById('ageMonth').value = ageMonths + " month" + (ageMonths === 1 ? "" : "s");
        document.getElementById('ageDay').value = ageDays + " day" + (ageDays === 1 ? "" : "s");
    }


    //------------------------------------------------------------------------------------------------

    function pincodeValidation(input) {
        let pincode = input.value;
        pincode = pincode.slice(0, 6);

        input.value = pincode;
    }
    const statesByCountry = {
        us: ["California", "Texas", "New York", "Florida"],
        ca: ["Ontario", "Quebec", "British Columbia", "Alberta"],
        uk: ["England", "Scotland", "Wales", "Northern Ireland"],
        au: ["New South Wales", "Victoria", "Queensland", "Western Australia"],
        in: ["Delhi", "Karnataka", "Tamil Nadu", "Kerala", "Mumbai"],
        jp: ["Tokyo", "Osaka", "Hokkaido", "Kyoto"]
    };

 

    const ccountrySelect = document.getElementById('cCountry');
    const cstateSelect = document.getElementById('cState');


    ccountrySelect.addEventListener('change', changeState);

    function changeState() {
        var cselectedCountry = ccountrySelect.value;

        cstateSelect.innerHTML = '<option value="" selected disabled>Choose a state</option>';

        if (statesByCountry[cselectedCountry]) {
            for (var i = 0; i < statesByCountry[cselectedCountry].length; i++) {
                var cstate = statesByCountry[cselectedCountry][i];
                var coption = document.createElement('option');
                coption.value = cstate;
                coption.textContent = cstate;
                cstateSelect.appendChild(coption);
            }
        }
    }


    //----------------------------------------------------------------------------------------------------

    function validatePhoneNumber(input) {
        let phoneNumber = input.value.replace(/\D/g, '');

        phoneNumber = phoneNumber.slice(0, 10);

        if (phoneNumber.length > 5) {
            phoneNumber = phoneNumber.slice(0, 5) + ' ' + phoneNumber.slice(5);
        }
        input.value = phoneNumber;
    }

    //---------------------------------------------------------------------------------------------------------
    function comunicationAddress() {
        const isChecked = document.getElementById('check1').checked;

        const streetAddress = document.querySelector('input[name="streetAddress"]').value;
        const city = document.querySelector('input[name="city"]').value;
        const state = document.querySelector('select[name="state"]');
        const postalCode = document.querySelector('input[name="pincode"]').value;
        const country = document.querySelector('select[name="country"]');

        const cStreetAddress = document.querySelector('input[name="cStreetAddress"]');
        const cCity = document.querySelector('input[name="cCity"]');
        const cState = document.querySelector('select[name="cState"]');
        const cPostalCode = document.querySelector('input[name="cpincode"]');
        const cCountry = document.querySelector('select[name="cCountry"]');

        if (isChecked) {
            cStreetAddress.value = streetAddress;
            cCity.value = city;
            cPostalCode.value = postalCode;
            cCountry.value = country.value;
            // Clear existing options and add new options for the communication address state dropdown
            updateStateDropdown(cCountry.value, cState);

            cState.value = state.value;

            cStreetAddress.readOnly = true;
            cCity.readOnly = true;
            cState.disabled = true;
            cPostalCode.readOnly = true;
            cCountry.disabled = true;
        } else {
            cStreetAddress.value = '';
            cCity.value = '';
            cState.value = '';
            cPostalCode.value = '';
            cCountry.value = '';

            cStreetAddress.readOnly = false;
            cCity.readOnly = false;
            cState.disabled = false;
            cPostalCode.readOnly = false;
            cCountry.disabled = false;
        }
    }

    function updateStateDropdown(countryValue, stateSelect) {
        stateSelect.innerHTML = '<option value="" selected disabled>Choose a state</option>';

        const states = statesByCountry[countryValue] || [];
        states.forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateSelect.appendChild(option);
        });
    }
</script>

</body>

</html>