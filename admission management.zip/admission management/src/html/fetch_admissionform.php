<?php
// fetch_admissionform.php
include('connection.php'); // Include your database connection

if (isset($_POST['userId'])) {
  $userId = $_POST['userId'];
  
  // Query to fetch admission form data for the user where createdby = userId
  $query = "SELECT * FROM admissionform WHERE createdby = $userId";
  $result = mysqli_query($connection, $query);
  
  if (mysqli_num_rows($result) > 0) {
    // Output the admission form data in table rows
    while ($row = mysqli_fetch_assoc($result)) {
      echo "<tr>
              <td>" . $row['id'] . "</td>
              <td>" . $row['firstName'] . "</td>
              <td>" . $row['lastName'] . "</td>
              <td>" . $row['dateOfBirth'] . "</td>
              <td>" . $row['phoneNumber'] . "</td>
              <td>" . $row['city'] . "</td>
              <td>" . $row['pincode'] . "</td>
              <td>" . $row['qualification'] . "</td>
              <td>" . $row['marks'] . "</td>
            </tr>";
    }
  } else {
    echo "<tr><td colspan='9'>No admission forms found for this user.</td></tr>";
  }
}
?>
