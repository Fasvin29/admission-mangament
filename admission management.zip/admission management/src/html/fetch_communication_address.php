<?php
include("connection.php");

$admissionId = $_GET['id']; // Get the ID from the GET request
$query = "SELECT * FROM communicationaddress WHERE admissionid = '$admissionId'";
$data = mysqli_query($connection, $query);

$addresses = [];
while ($row = mysqli_fetch_assoc($data)) {
    $addresses[] = $row;
}

echo json_encode($addresses); // Return data as JSON
?>
