<?php
session_start();
include("connection.php");

$id = $_SESSION['id'];
$usertype = $_SESSION['usertype_id']; 

$query = ""; 

if ($usertype == 1) {
    $query = "SELECT yearofpassing, COUNT(*) AS total FROM admissionform GROUP BY yearofpassing";
} elseif ($usertype == 3) {
    $query = "SELECT yearofpassing, COUNT(*) AS total FROM admissionform WHERE createdby = $id GROUP BY yearofpassing";
} else {
    echo json_encode(["error" => "Unauthorized access"]);
    exit();
}

$result = mysqli_query($connection, $query);

if (!$result) {
    echo json_encode(["error" => "Query failed: " . mysqli_error($connection)]);
    exit();
}

// Fetch results into an array
$data = [];
while ($row = mysqli_fetch_assoc($result)) {
    $data[] = $row;
}

// Output JSON data for the fetch API
header('Content-Type: application/json');
echo json_encode($data);
?>
