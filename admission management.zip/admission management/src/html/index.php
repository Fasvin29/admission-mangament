<?php include("connection.php"); 

session_start(); // Start the session at the very beginning of the script

?>


<?php
if (isset($_POST['register'])) {

    $filename = $_FILES["photo"]["name"];
    $tempname = $_FILES["photo"]["tmp_name"];

    $folder = "photos/" . $filename; // Target path for storing photos
    $directory = "photos/"; // Base directory

    if (!is_dir($directory)) {
        mkdir($directory, 0777, true); // Create directory with proper permissions
    }

    // // Debugging: Print paths and check permissions
    // echo "Temp file: $tempname<br>";
    // echo "Target folder: $folder<br>";
    if (!is_writable($directory)) {
        // echo "Error: Directory $directory is not writable.<br>";
    }

    if (move_uploaded_file($tempname, $folder)) {
        // echo "File moved successfully to: $folder<br>";

        // Extract file extension
        $fileExtension = pathinfo($filename, PATHINFO_EXTENSION);

        // Construct the new name
        $newName = $directory . 'renamed_file_' . time() . '.' . $fileExtension;
        // echo "New file name: $newName<br>";

        // Check if the file exists before renaming
        if (file_exists($folder)) {
            if (rename($folder, $newName)) {
                // echo "File renamed successfully to: $newName";
            } else {
                echo "Error: Failed to rename the file.";
            }
        } else {
            echo "Error: File not found at $folder<br>";
        }
    } else {
        echo "Error: Failed to move uploaded file from $tempname to $folder.";
    }


    // Collecting form data
    $username      = $_POST['username'];
    $password      = $_POST['password'];
    $fname         = $_POST['firstName'];
    $mname         = $_POST['middleName'];
    $lname         = $_POST['lastName'];
    $dob           = $_POST['dateOfBirth'];
    $ph            = $_POST['phoneNumber'];
    $street        = $_POST['streetAddress'];
    $city          = $_POST['city'];
    $state         = $_POST['state'];
    $pincode       = $_POST['pincode'];
    $country       = $_POST['country'];
    $school        = $_POST['schoolName'];
    $qualification = $_POST['qualification'];
    $marks         = $_POST['marks'];
    $yop           = $_POST['yearOfPassing'];
    $pfname        = $_POST['parentFirstName'];
    $pmname        = $_POST['parentMiddleName'];
    $plname        = $_POST['parentLastName'];
    $pph           = $_POST['parentPhoneNumber'];
    $occupation    = $_POST['occupation'];

    $cStreet        = $_POST['cStreetAddress'];
    $cCity          = $_POST['cCity'];
    $cState         = isset($_POST['cState']) ? $_POST['cState'] : '';  // Check if state exists
    $cpincode       = $_POST['cpincode'];
    $cCountry       = isset($_POST['cCountry']) ? $_POST['cCountry'] : '';  // Check if country exists

    // Insert data into admissionform
    $query = "INSERT INTO admissionform (photo, firstName, middleName, lastName, dateOfBirth, phoneNumber, streetAddress, city, state, pincode, country, school, qualification, marks, yearofpassing, parentfirstname, parentmiddlename, parentlastname, parentphonenumber, occupation) 
              VALUES ('$newName','$fname', '$mname', '$lname', '$dob', '$ph', '$street', '$city', '$state', '$pincode', '$country', '$school', '$qualification', '$marks', '$yop', '$pfname', '$pmname', '$plname', '$pph', '$occupation')";
    $data = mysqli_query($connection, $query);

    if ($data) {
        // Get the admission form ID (auto incremented)
        $admissionId = mysqli_insert_id($connection);

        // Insert data into communicationaddress
        $query2 = "INSERT INTO communicationaddress (streetaddress, city, country, pincode, state, admissionid) 
                   VALUES ('$cStreet', '$cCity', '$cCountry', '$cpincode', '$cState', '$admissionId')";
        $data2 = mysqli_query($connection, $query2);

        if ($data2) {
            echo '<div class="alert alert-success alert-dismissible">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    Your application has been submitted successfully!</div>';
        } else {
            echo '<div class="alert alert-danger alert-dismissible">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    There was an error submitting your communication address. Please try again later.</div>';
        }
    } else {
        echo '<div class="alert alert-danger alert-dismissible">
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    There was an error submitting your application. Please try again later.</div>';
    }

    header('location:login.php');
}
?>

<?php include("header.php") ?>


<!--  Header End -->
<div class="container-fluid">
    <div class="card shadow-lg border border-5">
        <h5 class="card-title fw-semibold m-4">Application form</h5>
        <div class="card-body">
            <form action="#" method="POST" enctype="multipart/form-data">
                <section>
                    <div>
                        <label for="fullName" class="form-label h5 mt-3">Full Name of Applicant</label>
                        <div id="fullName" class="row">
                            <div class="col-12 col-md-6 col-lg-4">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="First" name="firstName" required>
                            </div>
                            <div class="col-12 col-md-6 col-lg-4 mt-3 mt-md-0">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="Middle" name="middleName">
                            </div>
                            <div class="col-12 col-md-6 col-lg-4 mt-3 mt-md-0">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="Last" name="lastName" required>
                            </div>
                        </div>
                    </div>
                    <div>
                        <label for="dateOfBirth" class="form-label h5 mt-3">Date of birth</label>
                        <input type="date" class="form-control border-1 border-primary rounded" id="dateOfBirth" placeholder="Date of Birth" name="dateOfBirth" required min="1900-01-01" max="<?php echo date('Y-m-d'); ?>" onchange="calculateAge()">
                    </div>
                    <div class="d-flex mt-3">
                        <label class="form-label h5 me-3">Age</label>
                        <input type="text" class="form-control me-3 border-1 border-primary rounded" id="ageYear" placeholder="Year" name="ageYear" readonly>
                        <input type="text" class="form-control me-3 border-1 border-primary rounded" id="ageMonth" placeholder="Month" name="ageMonth" readonly>
                        <input type="text" class="form-control border-1 border-primary rounded" id="ageDay" placeholder="Days" name="ageDay" readonly>
                    </div>

                    <div>
                        <label for="phoneNumber" class="form-label h5 mt-3">Applicant's Phone</label>
                        <input type="text" class="form-control border-1 border-primary rounded" id="phoneNumber" placeholder="" name="phoneNumber" oninput="validatePhoneNumber(this)" required>
                    </div>
                    <div>
                        <div class="d-flex mt-3">
                            <label for="photo" class="form-label h5 ">Upload Photo</label>
                            <input type="file" class="form-control border-1 border-primary rounded ms-3 w-25" id="photo" placeholder="" name="photo" required>
                            <div class=" ms-3">
                                <img id="photoPreview" src="#" alt="Photo Preview" class="border-1 border-primary rounded" style="display: none; max-width: 100px;">
                            </div>
                        </div>
                        <small id="fileError" class="text-danger"></small>
                    </div>
                    <div>
                        <label for="address" class="form-label h5 mt-3">Permanent Address</label>
                        <div id="address" class="row">
                            <div class="col-12">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="Street Address"
                                    name="streetAddress" required>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="City" name="city" required>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <select id="country" class="form-select border-1 border-primary rounded" name="country" required>
                                    <option value="" selected disabled>Country</option>
                                    <option value="us">United States</option>
                                    <option value="ca">Canada</option>
                                    <option value="uk">United Kingdom</option>
                                    <option value="au">Australia</option>
                                    <option value="in">India</option>
                                    <option value="jp">Japan</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <input type="number" class="form-control border-1 border-primary rounded" placeholder="Postal/ Zip Code"
                                    name="pincode" required oninput="pincodeValidation(this)">
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <!-- <input type="text" class="form-control" placeholder="State" name="state" required> -->
                                <select id="state" class="form-select border-1 border-primary rounded" name="state" required>
                                    <option value="" selected disabled>Choose a state</option>
                                </select>
                            </div>
                            <br>

                        </div>
                    </div>
                    <div>
                        <label for="address" class="form-label h5 mt-3">Communication Address</label>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input border-1 border-primary rounded" id="check1" name="comunication_check" value="something" onclick="comunicationAddress()">
                            <label class="form-check-label h6" for="check1">Communication address is same as Permanent address</label>
                        </div>
                        <div id="communicationAddress" class="row">
                            <div class="col-12">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="Street Address"
                                    name="cStreetAddress" required>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="City" name="cCity" required>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <select id="cCountry" class="form-select border-1 border-primary rounded" name="cCountry" required>
                                    <option value="" selected disabled>Country</option>
                                    <option value="us">United States</option>
                                    <option value="ca">Canada</option>
                                    <option value="uk">United Kingdom</option>
                                    <option value="au">Australia</option>
                                    <option value="in">India</option>
                                    <option value="jp">Japan</option>
                                </select>
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <input type="number" class="form-control border-1 border-primary rounded" placeholder="Postal/ Zip Code"
                                    name="cpincode" required oninput="pincodeValidation(this)">
                            </div>
                            <div class="col-12 col-md-6 mt-3">
                                <!-- <input type="text" class="form-control" placeholder="State" name="state" required> -->
                                <select id="cState" class="form-select border-1 border-primary rounded" name="cState" required>
                                    <option value="" selected disabled>Choose a state</option>
                                </select>
                            </div>
                            <br>
                            <br>
                            <br>
                            <hr>
                        </div>
                    </div>
                </section>
                <section>
                    <h4>Education details</h4>
                    <div>
                        <label for="schoolName" class="form-label h5 mt-3">Last school/ College Name</label>
                        <input type="text" class="form-control border-1 border-primary rounded" id="schoolName" placeholder="" name="schoolName" required>
                    </div>
                    <div>
                        <label for="qualificatin" class="form-label h5 mt-3">Highest Qualification</label>
                        <input type="text" class="form-control border-1 border-primary rounded" id="qualificatin" placeholder="" name="qualification" required>
                    </div>
                    <div>
                        <label for="marks" class="form-label h5 mt-3">Marks/ Percentage/ Grade</label>
                        <input type="text" class="form-control border-1 border-primary rounded" id="marks" placeholder="" name="marks" required>
                    </div>
                    <div>
                        <label for="yearOfPassing" class="form-label h5 mt-3 ">Year Of Passing</label>
                        <select class="form-control border-1 border-primary rounded" id="yearOfPassing" name="yearOfPassing" required>
                            <?php
                            $currentYear = date('Y');
                            for ($year = 1950; $year <= $currentYear; $year++) {
                                $selected = ($year == $currentYear) ? 'selected' : '';
                                echo "<option value='$year' $selected>$year</option>";
                            }
                            ?>
                        </select>
                    </div>

                    <hr>
                </section>
                <section>
                    <div>
                        <label for="parentFullName" class="form-label h5 ">Parent/ Guardian's Name</label>
                        <div id="parentFullName" class="row">
                            <div class="col-12 col-md-6 col-lg-4">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="First" name="parentFirstName" required>
                            </div>
                            <div class="col-12 col-md-6 col-lg-4 mt-3 mt-md-0">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="Middle" name="parentMiddleName">
                            </div>
                            <div class="col-12 col-md-6 col-lg-4 mt-3 mt-md-0">
                                <input type="text" class="form-control border-1 border-primary rounded" placeholder="Last" name="parentLastName" required>
                            </div>
                            <div>
                                <label for="parentPhoneNumber" class="form-label h5 mt-3">Parent/ Guardian's
                                    Phone</label>
                                <input type="text" class="form-control border-1 border-primary rounded" id="parentPhoneNumber"
                                    placeholder="" name="parentPhoneNumber" required oninput="validatePhoneNumber(this)">
                            </div>
                            <div>
                                <label for="occupation" class="form-label h5 mt-3">Occupation</label>
                                <input type="text" class="form-control border-1 border-primary rounded" id="occupation" placeholder="Occupation"
                                    name="occupation">
                            </div>
                        </div>
                    </div>
                </section>
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-primary mt-3" name="register">Submit</button>
                    <!-- <input type="submit" value="Register" class="btn" name="register"> -->
                </div>
            </form>
        </div>

    </div>
</div>
</div>
</div>
<script src="../assets/libs/jquery/dist/jquery.min.js"></script>
<script src="../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/sidebarmenu.js"></script>
<script src="../assets/js/app.min.js"></script>
<script src="../assets/libs/simplebar/dist/simplebar.js"></script>

<script>
    function calculateAge() {
        const dob = document.getElementById('dateOfBirth').value;
        const birthDate = new Date(dob);
        const currentDate = new Date();

        let ageYears = currentDate.getFullYear() - birthDate.getFullYear();
        let ageMonths = currentDate.getMonth() - birthDate.getMonth();
        let ageDays = currentDate.getDate() - birthDate.getDate();

        //adjusts the negative values (month 2-11 = -9, by adding 12 months it gives 3 and decreases one year)
        if (ageMonths < 0) {
            ageYears--;
            ageMonths += 12;
        }
        if (ageDays < 0) {
            ageMonths--;
            const daysInPrevMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 0).getDate();
            ageDays += daysInPrevMonth;
        }

        document.getElementById('ageYear').value = ageYears + " year" + (ageYears === 1 ? "" : "s");
        document.getElementById('ageMonth').value = ageMonths + " month" + (ageMonths === 1 ? "" : "s");
        document.getElementById('ageDay').value = ageDays + " day" + (ageDays === 1 ? "" : "s");
    }


    //------------------------------------------------------------------------------------------------

    function pincodeValidation(input) {
        let pincode = input.value;
        pincode = pincode.slice(0, 6);

        input.value = pincode;
    }
    const statesByCountry = {
        us: ["California", "Texas", "New York", "Florida"],
        ca: ["Ontario", "Quebec", "British Columbia", "Alberta"],
        uk: ["England", "Scotland", "Wales", "Northern Ireland"],
        au: ["New South Wales", "Victoria", "Queensland", "Western Australia"],
        in: ["Delhi", "Karnataka", "Tamil Nadu", "Kerala", "Mumbai"],
        jp: ["Tokyo", "Osaka", "Hokkaido", "Kyoto"]
    };

    const countrySelect = document.getElementById('country');
    const stateSelect = document.getElementById('state');

    const ccountrySelect = document.getElementById('cCountry');
    const cstateSelect = document.getElementById('cState');


    countrySelect.addEventListener('change', changeState);
    ccountrySelect.addEventListener('change', changeState);

    function changeState() {
        var selectedCountry = countrySelect.value;
        var cselectedCountry = ccountrySelect.value;

        stateSelect.innerHTML = '<option value="" selected disabled>Choose a state</option>';
        cstateSelect.innerHTML = '<option value="" selected disabled>Choose a state</option>';

        if (statesByCountry[selectedCountry]) {
            for (var i = 0; i < statesByCountry[selectedCountry].length; i++) {
                var state = statesByCountry[selectedCountry][i];
                var option = document.createElement('option');
                option.value = state;
                option.textContent = state;
                stateSelect.appendChild(option);
            }
        }
        if (statesByCountry[cselectedCountry]) {
            for (var i = 0; i < statesByCountry[cselectedCountry].length; i++) {
                var cstate = statesByCountry[cselectedCountry][i];
                var coption = document.createElement('option');
                coption.value = cstate;
                coption.textContent = cstate;
                cstateSelect.appendChild(coption);
            }
        }
    }


    //----------------------------------------------------------------------------------------------------

    function validatePhoneNumber(input) {
        let phoneNumber = input.value.replace(/\D/g, '');

        phoneNumber = phoneNumber.slice(0, 10);

        if (phoneNumber.length > 5) {
            phoneNumber = phoneNumber.slice(0, 5) + ' ' + phoneNumber.slice(5);
        }
        input.value = phoneNumber;
    }

    //---------------------------------------------------------------------------------------------------------
    function comunicationAddress() {
        const isChecked = document.getElementById('check1').checked;

        const streetAddress = document.querySelector('input[name="streetAddress"]').value;
        const city = document.querySelector('input[name="city"]').value;
        const state = document.querySelector('select[name="state"]');
        const postalCode = document.querySelector('input[name="pincode"]').value;
        const country = document.querySelector('select[name="country"]');

        const cStreetAddress = document.querySelector('input[name="cStreetAddress"]');
        const cCity = document.querySelector('input[name="cCity"]');
        const cState = document.querySelector('select[name="cState"]');
        const cPostalCode = document.querySelector('input[name="cpincode"]');
        const cCountry = document.querySelector('select[name="cCountry"]');

        if (isChecked) {
            cStreetAddress.value = streetAddress;
            cCity.value = city;
            cPostalCode.value = postalCode;
            cCountry.value = country.value;
            // Clear existing options and add new options for the communication address state dropdown
            updateStateDropdown(cCountry.value, cState);

            cState.value = state.value;

            cStreetAddress.readOnly = true;
            cCity.readOnly = true;
            cState.disabled = true;
            cPostalCode.readOnly = true;
            cCountry.disabled = true;
        } else {
            cStreetAddress.value = '';
            cCity.value = '';
            cState.value = '';
            cPostalCode.value = '';
            cCountry.value = '';

            cStreetAddress.readOnly = false;
            cCity.readOnly = false;
            cState.disabled = false;
            cPostalCode.readOnly = false;
            cCountry.disabled = false;
        }
    }

    function updateStateDropdown(countryValue, stateSelect) {
        stateSelect.innerHTML = '<option value="" selected disabled>Choose a state</option>';

        const states = statesByCountry[countryValue] || [];
        states.forEach(state => {
            const option = document.createElement('option');
            option.value = state;
            option.textContent = state;
            stateSelect.appendChild(option);
        });
    }

    document.getElementById('photo').onchange = function() {
        filesize
    };

    // -----------------------------------------------------------------------------------------
    // Function to handle file size and type validation
    // Function to handle file size and type validation
    function filesize() {
        const file = this.files[0]; // Get the selected file
        const maxSize = 200 * 1024; // 200 KB in bytes
        const allowedFormats = ['image/jpeg', 'image/png']; // Allowed MIME types

        const fileError = document.getElementById('fileError'); // Error display element

        if (file) {
            // Check file size
            if (file.size > maxSize) {
                fileError.textContent = 'File size must not exceed 200 KB.';
                this.value = ''; // Clear the file input
                return;
            }

            // Check file type
            if (!allowedFormats.includes(file.type)) {
                fileError.textContent = 'Only JPEG and PNG formats are allowed.';
                this.value = ''; // Clear the file input
                return;
            }

            // Clear error if all validations pass
            fileError.textContent = '';
        }
    }

    // Function to display the image preview
    document.getElementById('photo').addEventListener('change', function() {
        const file = this.files[0]; // Get the first selected file
        const fileError = document.getElementById('fileError'); // Error display element

        if (file) {
            // Check if the file is an image
            if (file.type.startsWith('image/')) {
                // Validate file type and size before proceeding
                if (file.size > 200 * 1024) {
                    fileError.textContent = 'File size must not exceed 200 KB.';
                    this.value = ''; // Reset the file input
                    return;
                }

                if (!['image/jpeg', 'image/png'].includes(file.type)) {
                    fileError.textContent = 'Please upload a valid image file (JPEG or PNG).';
                    this.value = ''; // Reset the file input
                    return;
                }

                // Clear error if all validations pass
                fileError.textContent = '';

                // Create a FileReader object
                const reader = new FileReader();

                // When the file is read, display the preview
                reader.onload = function(event) {
                    const photoPreview = document.getElementById('photoPreview');
                    photoPreview.src = event.target.result; // Set the image source to the file content
                    photoPreview.style.display = 'block'; // Make the image visible
                };

                reader.readAsDataURL(file); // Read the file as a data URL
            } else {
                fileError.textContent = 'Please upload a valid image file (JPEG or PNG).';
                this.value = ''; // Reset the file input
            }
        }
    });
</script>
</body>

</html>