<?php
include("connection.php");

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $streetaddress = $_POST['streetaddress'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $country = $_POST['country'];
    $pincode = $_POST['pincode'];

    $query = "UPDATE communication_address SET 
              streetaddress = '$streetaddress', 
              city = '$city', 
              state = '$state', 
              country = '$country', 
              pincode = '$pincode' 
              WHERE id = $id";

    if (mysqli_query($connection, $query)) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }
}
?>
