<?php
if (isset($_POST['update'])) {
    // Directory where files will be uploaded
    $folder = 'photos/';
    
    // Ensure the directory exists
    if (!is_dir($folder)) {
        mkdir($folder, 0777, true); // Create directory with proper permissions
    }

    // Get file details
    $tempname = $_FILES['photo']['tmp_name'];
    $filename = $_FILES['photo']['name']; 
    $fileSize = $_FILES['photo']['size'];
    $fileError = $_FILES['photo']['error'];

    // Check for upload errors
    if ($fileError === UPLOAD_ERR_OK) {
        // Continue to move the file
    } else {
        die('Error during file upload.');
    }
}



// Allow only specific file extensions
$allowedExtensions = ['jpg', 'png'];
$fileExtension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));

if (!in_array($fileExtension, $allowedExtensions)) {
    die('Invalid file type. Only JPG and PNG are allowed.');
}

// Limit file size (e.g., 2MB)
$maxFileSize = 200 * 1024; // 2 MB
if ($fileSize > $maxFileSize) {
    die('File size exceeds the 5MB limit.');
}




    // Generate a unique name for the file
$newFileName = uniqid('file_', true) . '.' . $fileExtension;

// Full path to the new file
$destinationPath = $folder . $newFileName;

// Move the uploaded file to the destination
if (move_uploaded_file($tempname, $destinationPath)) {
    echo 'File uploaded successfully.';

    // Optional: Rename the file
    $newName = $folder . 'renamed_file_' . time() . '.' . $fileExtension;
    if (rename($destinationPath, $newName)) {
        echo " File renamed to $newName.";
    } else {
        echo " Failed to rename the file.";
    }
} else {
    die('Failed to move the uploaded file.');
}
?>
